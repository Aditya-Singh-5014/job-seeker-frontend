// frontend/src/components/sidebar-components/jobs/Jobs.jsx
import React, { useEffect, useState } from "react";
import api from "../../../services/api";

const Jobs = () => {
  const [jobs, setJobs] = useState([]);

  useEffect(() => {
    const fetchJobs = async () => {
      try {
        const response = await api.get("/jobs");
        setJobs(response.data.jobs);
      } catch (error) {
        console.error(error);
      }
    };

    fetchJobs();
  }, []);

  const applyToJob = async (jobId) => {
    try {
      await api.post(`/jobs/${jobId}/apply`);
      alert("Applied to job successfully!");
    } catch (error) {
      console.error(error);
      alert("Failed to apply to job.");
    }
  };

  return (
    <div className="p-6 bg-white rounded shadow-md">
      <h2 className="text-2xl font-bold mb-4">Available Jobs</h2>
      {jobs.map((job) => (
        <div key={job.id} className="mb-4 p-4 border rounded">
          <h3 className="text-xl font-semibold">{job.title}</h3>
          <p>{job.description}</p>
          <button
            onClick={() => applyToJob(job.id)}
            className="mt-2 bg-blue-500 text-white py-1 px-3 rounded"
          >
            Apply
          </button>
        </div>
      ))}
    </div>
  );
};

export default Jobs;
