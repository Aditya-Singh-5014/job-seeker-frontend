// frontend/src/App.js
import React from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
} from "react-router-dom";
import Dashboard from "./components/Dashboard";
import RecruiterDashboard from "./components/recruiter/RecruiterDashboard";
import LandingPage from "./components/LandingPage";
import SignUp from "./components/auth/jobseeker/SignUp";
import Login from "./components/auth/jobseeker/Login";
import RecruiterSignUp from "./components/auth/recruiter/SignUp";
import RecruiterLogin from "./components/auth/recruiter/Login";
import Home from "./components/sidebar-components/home/Home";
import { AuthProvider } from "./context/AuthContext";
import { RecruiterAuthProvider } from "./context/RecruiterAuthContext";
import ProtectedRoute from "./components/common/ProtectedRoute";
import Jobs from "./components/sidebar-components/jobs/Jobs";
// import JobDetails from "./components/sidebar-components/jobs/JobDetails";
import CreateJob from "./components/recruiter/CreateJob";

function App() {
  return (
    <AuthProvider>
      <RecruiterAuthProvider>
        <Router>
          <Routes>
            {/* Public Routes */}
            <Route path="/" element={<LandingPage />} />

            {/* Job Seeker Auth */}
            <Route path="/auth/jobseeker/signup" element={<SignUp />} />
            <Route path="/auth/jobseeker/login" element={<Login />} />

            {/* Recruiter Auth */}
            <Route
              path="/auth/recruiter/signup"
              element={<RecruiterSignUp />}
            />
            <Route path="/auth/recruiter/login" element={<RecruiterLogin />} />

            {/* Protected Job Seeker Routes */}
            <Route element={<ProtectedRoute />}>
              <Route path="/dashboard/*" element={<Dashboard />}>
                <Route path="home" element={<Home />} />
                <Route path="jobs" element={<Jobs />} />
                {/* <Route path="jobs/:id" element={<JobDetails />} />{" "} */}
                {/* Job Details Route */}
                {/* Other job seeker routes */}
              </Route>
            </Route>

            {/* Protected Recruiter Routes */}
            <Route element={<ProtectedRoute isRecruiter />}>
              <Route
                path="/recruiter/dashboard/*"
                element={<RecruiterDashboard />}
              >
                <Route path="home" element={<CreateJob />} />
                <Route path="create-job" element={<CreateJob />} />
                {/* Other recruiter routes */}
              </Route>
            </Route>

            {/* Redirect any undefined routes to landing page */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </Router>
      </RecruiterAuthProvider>
    </AuthProvider>
  );
}

export default App;
